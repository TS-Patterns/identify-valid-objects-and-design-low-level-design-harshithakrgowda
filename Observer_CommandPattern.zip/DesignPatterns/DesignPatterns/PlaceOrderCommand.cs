﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommandPattern
{
    class PlaceOrderCommand : ICommand
    {
        IFoodOrder _foodOrder;

        public PlaceOrderCommand(IFoodOrder foodOrder)
        {
            _foodOrder = foodOrder;
        }

        public void Execute()
        {
            _foodOrder.PlaceOrder();
        }
    }
}
