﻿using System;

namespace CommandPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            IFoodOrder food = new FoodOrder();
            ICommand placeOrder = new PlaceOrderCommand(food);
            ICommand cancelOrder = new CancelOrderCommand(food);
            Menu menu = new Menu(placeOrder, cancelOrder);
            Console.WriteLine("Place Order : Press Y ; Cancel Order : Press N");
            string reply = Console.ReadLine();
            if(reply == "Y")
            {
                menu.PlaceItem();  
            }
            else if(reply == "N")
            {
                menu.CancelItem();
            }
            else
            {
                Console.WriteLine("Press Y or N");
            }
        }
    }
}
