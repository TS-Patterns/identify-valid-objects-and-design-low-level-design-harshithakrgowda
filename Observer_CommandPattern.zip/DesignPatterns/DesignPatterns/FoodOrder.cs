﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommandPattern
{
    class FoodOrder : IFoodOrder
    {
        public void CancelOrder()
        {
            Console.WriteLine("Order cancelled");
        }

        public void PlaceOrder()
        {
            Console.WriteLine("Placed Order");
        }
    }
}
