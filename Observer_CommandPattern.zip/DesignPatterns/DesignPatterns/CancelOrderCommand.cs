﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommandPattern
{
    class CancelOrderCommand : ICommand
    {
        IFoodOrder _foodOrder;

        public CancelOrderCommand(IFoodOrder foodOrder)
        {
            _foodOrder = foodOrder;
        }

        public void Execute()
        {
            _foodOrder.CancelOrder();
        }
    }
}
