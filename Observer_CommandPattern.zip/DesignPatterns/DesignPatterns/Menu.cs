﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommandPattern
{
    class Menu
    {
        ICommand _placeItem;
        ICommand _cancelItem;

        public Menu(ICommand placeItem,ICommand cancelItem)
        {
            _placeItem = placeItem;
            _cancelItem = cancelItem;
        }

        public void PlaceItem()
        {
            _placeItem.Execute();
        }

        public void CancelItem()
        {
            _cancelItem.Execute();
        }
    }
}
